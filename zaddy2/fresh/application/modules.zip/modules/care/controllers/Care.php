<?php

class Care extends MX_Controller{
    
    
    
    public function index(){
        
        redirect(base_url()."solutions");
        
    }
    
    
}


?>