<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends MX_Controller {


	public function __construct()
        {
                parent::__construct();
                //Modules::run("auth/adminLegal");
                Modules::run("auth/isLegal");
        }

	
	public function index()
	{
		$this->load->view('sign_in');
	}



public function merchant()
	{
		
		$data['module']="user";
		$data['view'] ="home";
		$data['categories']=$this->getCategories();
		$data['page']="Dashboard";

        echo Modules::run('templates/user',$data);
	}

public function getCategories(){

		$categories=$this->db->get("categories")->result();

		return $categories;
	}



}
